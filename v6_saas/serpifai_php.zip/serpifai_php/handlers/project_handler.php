<?php
/**
 * Project Handler
 * Replaces Apps Script PropertiesService with MySQL database
 * Manages project CRUD operations
 */

require_once __DIR__ . '/../config/db_config.php';

/**
 * Save project to database
 */
function saveProject($licenseKey, $projectName, $projectData) {
    $db = getDbConnection();
    
    if (!$db) {
        return [
            'success' => false,
            'error' => 'Database connection failed'
        ];
    }
    
    try {
        // Check if project exists
        $stmt = $db->prepare("
            SELECT id FROM projects 
            WHERE license_key = ? AND project_name = ?
        ");
        $stmt->bind_param('ss', $licenseKey, $projectName);
        $stmt->execute();
        $result = $stmt->get_result();
        
        if ($result->num_rows > 0) {
            // Update existing project
            $row = $result->fetch_assoc();
            $projectId = $row['id'];
            
            $stmt = $db->prepare("
                UPDATE projects 
                SET project_data = ?, updated_at = NOW()
                WHERE id = ?
            ");
            $jsonData = json_encode($projectData);
            $stmt->bind_param('si', $jsonData, $projectId);
            $stmt->execute();
            
            return [
                'success' => true,
                'message' => 'Project updated successfully',
                'projectId' => $projectId,
                'updated' => true
            ];
        } else {
            // Insert new project
            $stmt = $db->prepare("
                INSERT INTO projects (license_key, project_name, project_data)
                VALUES (?, ?, ?)
            ");
            $jsonData = json_encode($projectData);
            $stmt->bind_param('sss', $licenseKey, $projectName, $jsonData);
            $stmt->execute();
            
            return [
                'success' => true,
                'message' => 'Project created successfully',
                'projectId' => $db->insert_id,
                'created' => true
            ];
        }
    } catch (Exception $e) {
        return [
            'success' => false,
            'error' => 'Failed to save project: ' . $e->getMessage()
        ];
    } finally {
        $db->close();
    }
}

/**
 * Load project from database
 */
function loadProject($licenseKey, $projectName) {
    $db = getDbConnection();
    
    if (!$db) {
        return [
            'success' => false,
            'error' => 'Database connection failed'
        ];
    }
    
    try {
        $stmt = $db->prepare("
            SELECT project_data, created_at, updated_at 
            FROM projects 
            WHERE license_key = ? AND project_name = ?
        ");
        $stmt->bind_param('ss', $licenseKey, $projectName);
        $stmt->execute();
        $result = $stmt->get_result();
        
        if ($result->num_rows === 0) {
            return [
                'success' => false,
                'error' => 'Project not found'
            ];
        }
        
        $row = $result->fetch_assoc();
        
        return [
            'success' => true,
            'data' => json_decode($row['project_data'], true),
            'metadata' => [
                'created_at' => $row['created_at'],
                'updated_at' => $row['updated_at']
            ]
        ];
    } catch (Exception $e) {
        return [
            'success' => false,
            'error' => 'Failed to load project: ' . $e->getMessage()
        ];
    } finally {
        $db->close();
    }
}

/**
 * List all projects for user
 */
function listProjects($licenseKey) {
    $db = getDbConnection();
    
    if (!$db) {
        return [
            'success' => false,
            'error' => 'Database connection failed'
        ];
    }
    
    try {
        $stmt = $db->prepare("
            SELECT project_name, created_at, updated_at 
            FROM projects 
            WHERE license_key = ?
            ORDER BY updated_at DESC
        ");
        $stmt->bind_param('s', $licenseKey);
        $stmt->execute();
        $result = $stmt->get_result();
        
        $projects = [];
        while ($row = $result->fetch_assoc()) {
            $projects[] = [
                'name' => $row['project_name'],
                'created_at' => $row['created_at'],
                'updated_at' => $row['updated_at']
            ];
        }
        
        return [
            'success' => true,
            'data' => $projects,
            'count' => count($projects)
        ];
    } catch (Exception $e) {
        return [
            'success' => false,
            'error' => 'Failed to list projects: ' . $e->getMessage()
        ];
    } finally {
        $db->close();
    }
}

/**
 * Delete project
 */
function deleteProject($licenseKey, $projectName) {
    $db = getDbConnection();
    
    if (!$db) {
        return [
            'success' => false,
            'error' => 'Database connection failed'
        ];
    }
    
    try {
        $stmt = $db->prepare("
            DELETE FROM projects 
            WHERE license_key = ? AND project_name = ?
        ");
        $stmt->bind_param('ss', $licenseKey, $projectName);
        $stmt->execute();
        
        if ($stmt->affected_rows === 0) {
            return [
                'success' => false,
                'error' => 'Project not found'
            ];
        }
        
        return [
            'success' => true,
            'message' => 'Project deleted successfully'
        ];
    } catch (Exception $e) {
        return [
            'success' => false,
            'error' => 'Failed to delete project: ' . $e->getMessage()
        ];
    } finally {
        $db->close();
    }
}

/**
 * Rename project
 */
function renameProject($licenseKey, $oldName, $newName) {
    $db = getDbConnection();
    
    if (!$db) {
        return [
            'success' => false,
            'error' => 'Database connection failed'
        ];
    }
    
    try {
        // Check if new name already exists
        $stmt = $db->prepare("
            SELECT id FROM projects 
            WHERE license_key = ? AND project_name = ?
        ");
        $stmt->bind_param('ss', $licenseKey, $newName);
        $stmt->execute();
        $result = $stmt->get_result();
        
        if ($result->num_rows > 0) {
            return [
                'success' => false,
                'error' => 'A project with that name already exists'
            ];
        }
        
        // Rename project
        $stmt = $db->prepare("
            UPDATE projects 
            SET project_name = ?, updated_at = NOW()
            WHERE license_key = ? AND project_name = ?
        ");
        $stmt->bind_param('sss', $newName, $licenseKey, $oldName);
        $stmt->execute();
        
        if ($stmt->affected_rows === 0) {
            return [
                'success' => false,
                'error' => 'Project not found'
            ];
        }
        
        return [
            'success' => true,
            'message' => 'Project renamed successfully'
        ];
    } catch (Exception $e) {
        return [
            'success' => false,
            'error' => 'Failed to rename project: ' . $e->getMessage()
        ];
    } finally {
        $db->close();
    }
}

/**
 * Duplicate project
 */
function duplicateProject($licenseKey, $sourceName, $targetName) {
    // Load source project
    $sourceResult = loadProject($licenseKey, $sourceName);
    
    if (!$sourceResult['success']) {
        return $sourceResult;
    }
    
    // Save as new project
    return saveProject($licenseKey, $targetName, $sourceResult['data']);
}

/**
 * Get project statistics
 */
function getProjectStats($licenseKey) {
    $db = getDbConnection();
    
    if (!$db) {
        return [
            'success' => false,
            'error' => 'Database connection failed'
        ];
    }
    
    try {
        $stmt = $db->prepare("
            SELECT 
                COUNT(*) as total_projects,
                MIN(created_at) as first_project_date,
                MAX(updated_at) as last_activity_date
            FROM projects 
            WHERE license_key = ?
        ");
        $stmt->bind_param('s', $licenseKey);
        $stmt->execute();
        $result = $stmt->get_result();
        $stats = $result->fetch_assoc();
        
        return [
            'success' => true,
            'data' => $stats
        ];
    } catch (Exception $e) {
        return [
            'success' => false,
            'error' => 'Failed to get project stats: ' . $e->getMessage()
        ];
    } finally {
        $db->close();
    }
}

/**
 * Handle project action routing
 */
function handleProjectAction($action, $payload, $licenseKey) {
    switch ($action) {
        case 'project_save':
        case 'project:save':
            return saveProject($licenseKey, $payload['projectName'], $payload['projectData']);
            
        case 'project_load':
        case 'project:load':
            return loadProject($licenseKey, $payload['projectName']);
            
        case 'project_list':
        case 'project:list':
            return listProjects($licenseKey);
            
        case 'project_delete':
        case 'project:delete':
            return deleteProject($licenseKey, $payload['projectName']);
            
        case 'project_rename':
        case 'project:rename':
            return renameProject($licenseKey, $payload['oldName'], $payload['newName']);
            
        case 'project_duplicate':
        case 'project:duplicate':
            return duplicateProject($licenseKey, $payload['sourceName'], $payload['targetName']);
            
        case 'project_stats':
        case 'project:stats':
            return getProjectStats($licenseKey);
            
        default:
            return [
                'success' => false,
                'error' => 'Unknown project action: ' . $action
            ];
    }
}
